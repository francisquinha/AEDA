var searchData=
[
  ['dec_5fex_5fdisponiveis',['dec_ex_disponiveis',['../class_livro.html#a2b979b90662f34ae94d5ebf12b497626',1,'Livro']]],
  ['dec_5fexemplares',['dec_exemplares',['../class_livro.html#a03f48e98255ecf5ada99a86418c794d6',1,'Livro']]],
  ['del_5femp_5flivro',['del_emp_livro',['../class_livro.html#a858b859766ac487a58b0add34e036501',1,'Livro']]],
  ['desiste_5fpedido',['desiste_pedido',['../class_biblioteca.html#a70dae8f4cab9d946de1cd6325b8943e2',1,'Biblioteca']]],
  ['despromove_5fsupervisor_5ffuncionorario',['despromove_supervisor_funcionorario',['../class_biblioteca.html#a6ec145a14b5f2f000cc4525796e97b4b',1,'Biblioteca']]],
  ['distribui_5ffuncionarios',['distribui_funcionarios',['../class_biblioteca.html#a42d854d2e6e6f54c799fbf183c3ff81b',1,'Biblioteca']]]
];
