var searchData=
[
  ['hash_5fleitores',['Hash_Leitores',['../_biblio_8h.html#a46b0d4574bd66c4c2bbc31f5cc018fe3',1,'Biblio.h']]]
];
