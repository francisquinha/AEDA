var searchData=
[
  ['remove_5fdisponivel',['remove_disponivel',['../class_biblioteca.html#a05e52a51128df1a9cb71cc7faa7233f8',1,'Biblioteca']]],
  ['remove_5femp_5fleit',['remove_emp_leit',['../class_leitor.html#a590ec0a09a4c4c84a01ddc8845c019db',1,'Leitor']]],
  ['remove_5femprestimo',['remove_emprestimo',['../class_biblioteca.html#a7db15516eae5155f62d2bd27b2f05f15',1,'Biblioteca']]],
  ['remove_5ffuncionario',['remove_funcionario',['../class_biblioteca.html#ab6ddc278a5e08b9e7d17e47ba6577d99',1,'Biblioteca']]],
  ['remove_5finativo',['remove_inativo',['../class_biblioteca.html#a8f3ef4759aa5b09af976586cf013e9c0',1,'Biblioteca']]],
  ['remove_5fleitor',['remove_leitor',['../class_biblioteca.html#a1ad5204547cdbe657ed9b2a3ec958dac',1,'Biblioteca']]],
  ['remove_5flivro',['remove_livro',['../class_biblioteca.html#af44286b502ccd6901967381ac99b45ab',1,'Biblioteca']]],
  ['remove_5fped_5flivro',['remove_ped_livro',['../class_livro.html#a8e3c18a92873d983a84f0db94bd20e69',1,'Livro']]],
  ['remove_5fpedido',['remove_pedido',['../class_biblioteca.html#a60a7e10201539e9223456cb87858a34b',1,'Biblioteca']]],
  ['remove_5futilizador',['remove_utilizador',['../class_biblioteca.html#ad5bfe57ddd753ebff7a1b9982c82ddee',1,'Biblioteca']]]
];
