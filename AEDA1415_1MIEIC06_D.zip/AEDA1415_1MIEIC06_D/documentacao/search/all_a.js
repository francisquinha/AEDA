var searchData=
[
  ['object',['Object',['../class_object.html',1,'Object'],['../class_object.html#a2e1e8cbde22b050bb3442d1a6749f18b',1,'Object::Object()']]],
  ['object_2ecpp',['Object.cpp',['../_object_8cpp.html',1,'']]],
  ['object_2eh',['Object.h',['../_object_8h.html',1,'']]],
  ['object_5fnao_5fexiste',['Object_nao_existe',['../class_object__nao__existe.html',1,'Object_nao_existe'],['../class_object__nao__existe.html#a41b8505aa5b7d80f5380300068f08b7a',1,'Object_nao_existe::Object_nao_existe()']]],
  ['online',['online',['../class_utilizador__online.html#a09e5cfeaec19c89930754eccec688afe',1,'Utilizador_online']]],
  ['operator_3c_3c',['operator&lt;&lt;',['../_excecao_8h.html#a24d5d3a8c0f33fef365be3774ed473c1',1,'operator&lt;&lt;(std::ostream &amp;out, Object_nao_existe &amp;object):&#160;Excecao.h'],['../_excecao_8h.html#a6eddd464aaedca92b87dff691ee7f4bb',1,'operator&lt;&lt;(std::ostream &amp;out, Livro_indisponivel &amp;livro):&#160;Excecao.h'],['../_excecao_8h.html#a36ac12e5803af47465df565ff6e71b5f',1,'operator&lt;&lt;(std::ostream &amp;out, Livro_emprestado &amp;livro):&#160;Excecao.h'],['../_excecao_8h.html#a63a36f5eb9b9a1ccb7b0379a0314e8b1',1,'operator&lt;&lt;(std::ostream &amp;out, Emprestimos_por_devolver &amp;leitor):&#160;Excecao.h'],['../_excecao_8h.html#a1c2130118e9f51301066ab792c7a9c1b',1,'operator&lt;&lt;(std::ostream &amp;out, Maximo_emprestimos &amp;leitor):&#160;Excecao.h'],['../_excecao_8h.html#a6457d79cf728b8a09be5fc8cc34f2969',1,'operator&lt;&lt;(std::ostream &amp;out, Ficheiro_indisponivel &amp;ficheiro):&#160;Excecao.h']]]
];
