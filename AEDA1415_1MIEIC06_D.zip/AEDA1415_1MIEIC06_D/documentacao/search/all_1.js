var searchData=
[
  ['biblio_2ecpp',['Biblio.cpp',['../_biblio_8cpp.html',1,'']]],
  ['biblio_2eh',['Biblio.h',['../_biblio_8h.html',1,'']]],
  ['biblioteca',['Biblioteca',['../class_biblioteca.html',1,'Biblioteca'],['../class_biblioteca.html#a5e12ea4e7a4edb14d210a41708fc1c10',1,'Biblioteca::Biblioteca()']]]
];
