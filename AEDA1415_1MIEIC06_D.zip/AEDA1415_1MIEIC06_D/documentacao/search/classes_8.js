var searchData=
[
  ['utilizador',['Utilizador',['../class_utilizador.html',1,'']]],
  ['utilizador_5fonline',['Utilizador_online',['../class_utilizador__online.html',1,'']]]
];
