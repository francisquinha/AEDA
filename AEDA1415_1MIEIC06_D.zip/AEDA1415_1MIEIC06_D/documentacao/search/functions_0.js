var searchData=
[
  ['adiciona_5femp_5fleit',['adiciona_emp_leit',['../class_leitor.html#a8af72b72fa6b2f4b81f1260db15c2e61',1,'Leitor']]],
  ['adiciona_5femprestimo',['adiciona_emprestimo',['../class_biblioteca.html#acc03014984c068e7c0a29d2e07b5f6ad',1,'Biblioteca']]],
  ['adiciona_5femprestimo_5fold',['adiciona_emprestimo_old',['../class_biblioteca.html#a51d0ca5405bc3b68873b4d4da3f9bbf0',1,'Biblioteca']]],
  ['adiciona_5ffunc_5fsup',['adiciona_func_sup',['../class_funcionario.html#a0bdcd03d37ff41b48320b58ea5bcf3bb',1,'Funcionario::adiciona_func_sup()'],['../class_supervisor.html#a0b83ddf41c986a4cc9dbd0cf53faa120',1,'Supervisor::adiciona_func_sup()']]],
  ['adiciona_5ffuncionario',['adiciona_funcionario',['../class_biblioteca.html#a9f5910f372e1f115476b564b3a12116b',1,'Biblioteca']]],
  ['adiciona_5ffuncionario_5fold',['adiciona_funcionario_old',['../class_biblioteca.html#a634379c5a090a6ef977034ae08a22c92',1,'Biblioteca']]],
  ['adiciona_5fleitor',['adiciona_leitor',['../class_biblioteca.html#aa6b893b0cd6818ac580113d1081160e5',1,'Biblioteca']]],
  ['adiciona_5fleitor_5fold',['adiciona_leitor_old',['../class_biblioteca.html#ae37e19914883f94de745bc6743229488',1,'Biblioteca']]],
  ['adiciona_5flivro',['adiciona_livro',['../class_biblioteca.html#a51d882c3bad6e85c85b04d88fb11e41a',1,'Biblioteca']]],
  ['adiciona_5flivro_5fold',['adiciona_livro_old',['../class_biblioteca.html#a21887c90c2ed6a7a0d02192d446e3c84',1,'Biblioteca']]],
  ['adiciona_5futilizador',['adiciona_utilizador',['../class_biblioteca.html#a0d29eaba16e1f9c4dc3bbbe046c72b0e',1,'Biblioteca']]],
  ['administrador',['Administrador',['../class_administrador.html#a8320aed5f1940d98c96053e94b762da4',1,'Administrador']]]
];
