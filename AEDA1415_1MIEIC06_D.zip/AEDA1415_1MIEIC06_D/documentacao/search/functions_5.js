var searchData=
[
  ['ficheiro_5findisponivel',['Ficheiro_indisponivel',['../class_ficheiro__indisponivel.html#a306da8e4d6afe225c864125765bd921f',1,'Ficheiro_indisponivel']]],
  ['funcionario',['Funcionario',['../class_funcionario.html#a62fdfb7a2534ef69eb9a9431663e261b',1,'Funcionario::Funcionario(long id, std::string nom, bool ct)'],['../class_funcionario.html#a69ccdb913cf0cc0b31d53375d33bbd3c',1,'Funcionario::Funcionario(std::string nom, bool ct)']]],
  ['funcionario_5fold',['Funcionario_old',['../class_funcionario__old.html#ab069afb26ef11bf81923850b8a82774f',1,'Funcionario_old::Funcionario_old(long id, std::string nom, std::time_t dtf, bool ct)'],['../class_funcionario__old.html#aead2dcd647124343366593a71efbd09e',1,'Funcionario_old::Funcionario_old(long id, std::string nom, bool ct)']]],
  ['funcionarios_5fadicionar',['funcionarios_adicionar',['../class_menu.html#ab3dbca2ed575497348777628c244e89b',1,'Menu']]],
  ['funcionarios_5fantigos',['funcionarios_antigos',['../class_menu.html#a3f107889cada2969b6cf450db03709f9',1,'Menu']]],
  ['funcionarios_5fdespromover',['funcionarios_despromover',['../class_menu.html#ab5a824aa62a56c85825af76b22a21615',1,'Menu']]],
  ['funcionarios_5fpromover',['funcionarios_promover',['../class_menu.html#a86eb0406768f3a153822d9225957f028',1,'Menu']]],
  ['funcionarios_5fremover',['funcionarios_remover',['../class_menu.html#a6b3cddbb033c2c58b0af4f4b41f0eb78',1,'Menu']]]
];
