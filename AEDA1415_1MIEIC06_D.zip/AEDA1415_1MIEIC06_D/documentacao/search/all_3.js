var searchData=
[
  ['despromove_5fsupervisor_5ffuncionorario',['despromove_supervisor_funcionorario',['../class_biblioteca.html#ab9a721be8afe0ad5d92b3b1e68d36678',1,'Biblioteca']]],
  ['distribui_5ffuncionarios',['distribui_funcionarios',['../class_biblioteca.html#a42d854d2e6e6f54c799fbf183c3ff81b',1,'Biblioteca']]]
];
