var searchData=
[
  ['remove_5femp_5fleit',['remove_emp_leit',['../class_leitor.html#afc67b3b42ee93677b844b784c8aa8370',1,'Leitor']]],
  ['remove_5femprestimo',['remove_emprestimo',['../class_biblioteca.html#a2088051966aed41ff8d041dce130bae3',1,'Biblioteca']]],
  ['remove_5ffuncionario',['remove_funcionario',['../class_biblioteca.html#ac2b58d7dd336ac761b8dd32a19cbf6b5',1,'Biblioteca']]],
  ['remove_5fleitor',['remove_leitor',['../class_biblioteca.html#a8b0589802b31f8ce7eacd3e53e05699b',1,'Biblioteca']]],
  ['remove_5flivro',['remove_livro',['../class_biblioteca.html#a96a04a4546ace7031824b0beb78aa2ea',1,'Biblioteca']]],
  ['remove_5futilizador',['remove_utilizador',['../class_biblioteca.html#a4ee7ec3ddf802d0f57ad885a2c645f22',1,'Biblioteca']]]
];
