var searchData=
[
  ['utilizador',['Utilizador',['../class_utilizador.html#a4c6761daec35a3a02d3f304087b07c3b',1,'Utilizador']]],
  ['utilizador_5fonline',['Utilizador_online',['../class_utilizador__online.html#a428bed8939ec4dee118ae5ce51ba4685',1,'Utilizador_online']]],
  ['utilizadores_5fadicionar',['utilizadores_adicionar',['../class_menu.html#a1775071301fd25292869f0c62248e502',1,'Menu']]],
  ['utilizadores_5fremover',['utilizadores_remover',['../class_menu.html#a7cd32cbebf1bdd0b63fbf1af176803f5',1,'Menu']]]
];
